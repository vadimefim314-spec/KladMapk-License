# KladMapk License Server

1. Загрузить эти файлы в GitHub-репозиторий.
2. В Render создать Web Service из этого репозитория.
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `gunicorn app:app --bind 0.0.0.0:$PORT`
5. В Environment добавить:
   - TELEGRAM_BOT_TOKEN = токен бота (не публиковать в GitHub)
   - TELEGRAM_ADMIN_ID = 1496817191
   - BASE_URL = URL Render, например https://kladmapk-license.onrender.com
   - WEBHOOK_SECRET = случайная секретная строка
   - LICENSE_DAYS = 30

Эндпоинты:
POST /license/request {"device_id":"..."}
POST /license/check {"key":"...","device_id":"..."}
POST /telegram/webhook
GET /health

Важно: токен Telegram хранится только в Render Environment Variables.
